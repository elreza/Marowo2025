import streamlit as st
import pyodbc
import pandas as pd
import altair as alt
import re

# Fungsi koneksi ke database
def connect_to_db():
    return pyodbc.connect(
        'DRIVER={ODBC Driver 17 for SQL Server};'
        'SERVER=10.0.0.36;'
        'DATABASE=db_penduduk;'
        'UID=moh_sabri;'
        'PWD=moh_sabri'
    )

# Fungsi memuat data
@st.cache_data
def load_data():
    conn = connect_to_db()
    df = pd.read_sql("SELECT Nama, Alamat, Status_Keluarga FROM Tabel_DataPenduduk WHERE Alamat IS NOT NULL AND Status_Keluarga IS NOT NULL", conn)
    df['Alamat'] = df['Alamat'].astype(str).str.upper().str.strip()
    df['Status_Keluarga'] = df['Status_Keluarga'].astype(str).str.upper().str.strip()
    return df

# Ekstrak nama Dusun dari alamat
def ekstrak_dusun(alamat):
    match = re.search(r'DUSUN\s+\d+', alamat)
    return match.group(0) if match else 'LAINNYA'

# Ekstrak nama RT dari alamat
def ekstrak_rt(alamat):
    match = re.search(r'RT\.?\s*0*\d+', alamat)
    return match.group(0).replace('.', '').replace(' ', '') if match else 'LAINNYA'

# Fungsi untuk membuat pie chart
def buat_pie_chart(df_grouped, title):
    return alt.Chart(df_grouped).mark_arc(innerRadius=50).encode(
        theta=alt.Theta(field='Jumlah', type='quantitative'),
        color=alt.Color(field=title, type='nominal'),
        tooltip=[
            alt.Tooltip(f'{title}:N', title=title),
            alt.Tooltip('Jumlah:Q', title='Jumlah'),
            alt.Tooltip('Persentase:Q', title='Persentase (%)')
        ]
    ).properties(
        width=600,
        height=400,
        title=f"Distribusi Penduduk per {title}"
    )

# Aplikasi utama
def main():
    st.title("📊 Sebaran Penduduk Berdasarkan Dusun dan RT")

    df = load_data()

    # Ekstrak Dusun dan RT dari Alamat
    df['Dusun'] = df['Alamat'].apply(ekstrak_dusun)
    df['RT'] = df['Alamat'].apply(ekstrak_rt)

    # ======================== TABEL DUSUN DAN KEPALA KELUARGA ========================
    st.markdown("## 🏘️ Jumlah Penduduk dan Kepala Keluarga Berdasarkan Dusun")
    # Kelompokkan berdasarkan Dusun dan Status_Keluarga
    df_dusun = df.groupby('Dusun').agg(
        Jumlah=('Nama', 'count'),
        Jumlah_Kepala_Keluarga=('Status_Keluarga', lambda x: (x == 'KEPALA KELUARGA').sum())
    ).reset_index()

    df_dusun['Persentase'] = (df_dusun['Jumlah'] / df_dusun['Jumlah'].sum() * 100).round(2)

    st.dataframe(df_dusun, use_container_width=True)

    # ======================== PIE CHART DUSUN ========================
    pie_dusun = buat_pie_chart(df_dusun, 'Dusun')
    st.altair_chart(pie_dusun, use_container_width=True)

    # ======================== TABEL RT DAN KEPALA KELUARGA ========================
    st.markdown("## 🏠 Jumlah Penduduk dan Kepala Keluarga Berdasarkan RT")
    # Kelompokkan berdasarkan RT dan Status_Keluarga
    df_rt = df.groupby('RT').agg(
        Jumlah=('Nama', 'count'),
        Jumlah_Kepala_Keluarga=('Status_Keluarga', lambda x: (x == 'KEPALA KELUARGA').sum())
    ).reset_index()

    df_rt['Persentase'] = (df_rt['Jumlah'] / df_rt['Jumlah'].sum() * 100).round(2)

    st.dataframe(df_rt, use_container_width=True)

    # ======================== PIE CHART RT ========================
    pie_rt = buat_pie_chart(df_rt, 'RT')
    st.altair_chart(pie_rt, use_container_width=True)

if __name__ == "__main__":
    main()

import streamlit as st
import pandas as pd
import pyodbc
import altair as alt
from pandas.api.types import CategoricalDtype
from datetime import datetime

# Koneksi database SQL Server
server = '10.0.0.36'
database = 'db_penduduk'
username = 'moh_sabri'
password = 'moh_sabri'

conn = pyodbc.connect(
    f'DRIVER={{ODBC Driver 17 for SQL Server}};'
    f'SERVER={server};'
    f'DATABASE={database};'
    f'UID={username};'
    f'PWD={password}'
)

# Ambil data penduduk
data = pd.read_sql_query("SELECT Tanggal_Lahir FROM Tabel_DataPenduduk", conn)

def hitung_umur(tanggal_lahir):
    today = datetime.today()
    umur = today.year - tanggal_lahir.year
    if (today.month, today.day) < (tanggal_lahir.month, tanggal_lahir.day):
        umur -= 1  # Kurangi umur jika belum lewat ulang tahunnya di tahun ini
    return umur

# Pastikan kolom Tanggal_Lahir bertipe datetime
data['Tanggal_Lahir'] = pd.to_datetime(data['Tanggal_Lahir'])

# Hitung umur dengan apply
data['Umur'] = data['Tanggal_Lahir'].apply(hitung_umur)


# Fungsi klasifikasi usia
def kategori_usia(umur):
    if 0 <= umur <= 5:
        return 'Balita 0-5 thn'
    elif 6 <= umur <= 12:
        return 'Anak-anak 6-12 thn'
    elif 13 <= umur <= 17:
        return 'Remaja 13-17 thn'
    elif 18 <= umur <= 59:
        return 'Dewasa 18-59 thn'
    else:
        return 'Lansia 60+ thn'

# Urutan kategori usia
kategori_order = CategoricalDtype(
    categories=["Balita 0-5 thn", "Anak-anak 6-12 thn", "Remaja 13-17 thn", "Dewasa 18-59 thn", "Lansia 60+ thn"],
    ordered=True
)

# Tambah kolom kategori usia ke data
data['Kategori'] = data['Umur'].apply(kategori_usia)
data['Kategori'] = data['Kategori'].astype(kategori_order)

# Hitung jumlah dan persentase per kategori
jumlah_per_kategori = data['Kategori'].value_counts().sort_index()
total_penduduk = jumlah_per_kategori.sum()
df_kategori = jumlah_per_kategori.reset_index()
df_kategori.columns = ['Kategori Usia', 'Jumlah']
df_kategori['Persentase (%)'] = (df_kategori['Jumlah'] / total_penduduk * 100).round(2)

# Judul aplikasi
st.title("Statistik Penduduk Desa Marowo")
st.markdown("#### Berdasarkan Kategori Usia")

# Tampilkan diagram batang Altair
chart = alt.Chart(df_kategori).mark_bar(size=50).encode(
    x=alt.X('Kategori Usia:N', sort=None),
    y=alt.Y('Jumlah:Q'),
    color=alt.Color('Kategori Usia:N', scale=alt.Scale(scheme='set2')),
    tooltip=[
        alt.Tooltip('Kategori Usia:N', title='Kategori'),
        alt.Tooltip('Jumlah:Q', title='Jumlah'),
        alt.Tooltip('Persentase (%):Q', title='Persentase (%)')
    ]
).properties(
    width=700,
    height=400,
    title='Distribusi Jumlah Penduduk Berdasarkan Usia'
)

st.altair_chart(chart, use_container_width=True)

# Tampilkan tabel di bawah grafik
st.markdown("### Tabel Jumlah dan Persentase per Kategori Usia")
st.dataframe(df_kategori, use_container_width=True)

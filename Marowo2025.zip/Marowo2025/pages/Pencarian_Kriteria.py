import streamlit as st
import pandas as pd
import pyodbc
from fpdf import FPDF
import tempfile
from datetime import datetime

# ============ KONFIGURASI HALAMAN ============
st.set_page_config(page_title="Pencarian Kriteria Penduduk", layout="wide")

# ============ STATUS LOGIN ============
if "is_logged_in" not in st.session_state:
    st.session_state.is_logged_in = False

PASSWORD_BENAR = "1234"

# ============ LOGIN ============
if not st.session_state.is_logged_in:
    password_input = st.text_input("🔐 Masukkan Password Akses Halaman:", type="password")
    if password_input:
        if password_input == PASSWORD_BENAR:
            st.session_state.is_logged_in = True
            st.rerun()
        else:
            st.error("❌ Password salah. Akses ditolak.")
    st.stop()
else:
    # TOMBOL LOGOUT DI SIDEBAR
    if st.sidebar.button("🚪 Logout"):
        st.session_state.is_logged_in = False
        st.rerun()

# ============ KONEKSI DATABASE ============
def connect_to_sql_server():
    return pyodbc.connect(
        'DRIVER={ODBC Driver 17 for SQL Server};'
        'SERVER=10.0.0.36;'
        'DATABASE=db_penduduk;'
        'UID=moh_sabri;'
        'PWD=moh_sabri'
    )

# ============ HITUNG UMUR ============
def hitung_umur(tanggal_lahir):
    today = datetime.today()
    umur = today.year - tanggal_lahir.year
    if (today.month, today.day) < (tanggal_lahir.month, tanggal_lahir.day):
        umur -= 1
    return umur

# ============ FILTER DATA ============
def get_filtered_data(umur_min, umur_max, jenis_kelamin, pendidikan, pekerjaan, alamat, status_keluarga, status_perkawinan, nkk):
    conn = connect_to_sql_server()
    query = "SELECT * FROM Tabel_DataPenduduk"
    df = pd.read_sql(query, conn)
    conn.close()

    df['Tanggal_Lahir'] = pd.to_datetime(df['Tanggal_Lahir'], errors='coerce')
    df = df[df['Tanggal_Lahir'].notnull()]
    df['Umur'] = df['Tanggal_Lahir'].apply(hitung_umur)

    df = df[(df['Umur'] >= umur_min) & (df['Umur'] <= umur_max)]

    if jenis_kelamin != "Semua":
        df = df[df['Jenis_Kelamin'].str.strip().str.lower() == jenis_kelamin.lower().strip()]
    if pendidikan != "Semua":
        df = df[df['Pendidikan'].str.strip() == pendidikan.strip()]
    if pekerjaan != "Semua":
        df = df[df['Pekerjaan'] == pekerjaan]
    if alamat != "Semua":
        df = df[df['Alamat'] == alamat]
    if status_keluarga != "Semua":
        df = df[df['Status_Keluarga'] == status_keluarga]
    if status_perkawinan != "Semua":
        df = df[df['Status_Perkawinan'] == status_perkawinan]
    if nkk:
        df = df[df['NKK'] == nkk]

    return df

# ============ RESET FILTER ============
def reset_filters():
    st.session_state.umur_min = 0
    st.session_state.umur_max = 100
    st.session_state.jenis_kelamin = "Semua"
    st.session_state.pendidikan = "Semua"
    st.session_state.pekerjaan = "Semua"
    st.session_state.alamat = "Semua"
    st.session_state.status_keluarga = "Semua"
    st.session_state.status_perkawinan = "Semua"
    st.session_state.nkk_input = ""

# ============ EXPORT PDF ============
def generate_pdf(dataframe):
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", size=9)
    pdf.set_font("Arial", 'B', 12)
    pdf.cell(200, 10, txt="Laporan Data Penduduk", ln=True, align='C')
    pdf.ln(5)
    pdf.set_font("Arial", size=5)

    col_widths = [35, 18, 15, 18, 20, 20, 12, 22, 25, 7]
    headers = ["Nama", "NIK", "Jenis_Kelamin", "Alamat", "Tempat_Lahir", "Tanggal_Lahir", "Agama", "Pendidikan", "Pekerjaan", "Umur"]
    for i, header in enumerate(headers):
        pdf.cell(col_widths[i], 8, header, 1)
    pdf.ln()

    for _, row in dataframe.iterrows():
        pdf.cell(col_widths[0], 5, str(row["Nama"]), 1)
        pdf.cell(col_widths[1], 5, str(row["NIK"]), 1)
        pdf.cell(col_widths[2], 5, str(row["Jenis_Kelamin"]), 1)
        pdf.cell(col_widths[3], 5, str(row["Alamat"]), 1)
        pdf.cell(col_widths[4], 5, str(row["Tempat_Lahir"]), 1)
        pdf.cell(col_widths[5], 5, str(row["Tanggal_Lahir"]), 1)
        pdf.cell(col_widths[6], 5, str(row["Agama"]), 1)
        pdf.cell(col_widths[7], 5, str(row["Pendidikan"]), 1)
        pdf.cell(col_widths[8], 5, str(row["Pekerjaan"]), 1)
        pdf.cell(col_widths[9], 5, str(row["Umur"]), 1)
        pdf.ln()

    pdf.ln(5)
    pdf.set_font("Arial", '', 6)
    tanggal_cetak = datetime.now().strftime("%d/%m/%Y %H:%M")
    pdf.cell(200, 8, txt=f"Tanggal Cetak : {tanggal_cetak}", ln=True, align='L')
    pdf.cell(200, 8, txt=f"Jumlah Data    : {len(dataframe)}", ln=True, align='L')
    pdf.ln(5)
    pdf.set_font("Arial", 'I', 6)
    pdf.multi_cell(0, 8, "Catatan: Data ini dicetak otomatis dari sistem berdasarkan hasil pencarian. Pastikan data digunakan sesuai kebutuhan administrasi.")

    temp_pdf = tempfile.NamedTemporaryFile(delete=False, suffix=".pdf")
    pdf.output(temp_pdf.name)
    return temp_pdf.name

# ============ INISIALISASI STATE ============
for key, val in {
    "umur_min": 0, "umur_max": 100,
    "jenis_kelamin": "Semua",
    "pendidikan": "Semua",
    "pekerjaan": "Semua",
    "alamat": "Semua",
    "status_keluarga": "Semua",
    "status_perkawinan": "Semua",
    "nkk_input": ""
}.items():
    st.session_state.setdefault(key, val)

# ============ ANTARMUKA PENCARIAN ============
st.title("📋 Pencarian Data Penduduk")
st.sidebar.header("🔍 Filter Pencarian")

st.sidebar.number_input("Umur Minimum", min_value=0, key="umur_min")
st.sidebar.number_input("Umur Maksimum", min_value=0, key="umur_max")
st.sidebar.selectbox("Jenis Kelamin", ["Semua", "Laki - Laki", "Perempuan"], key="jenis_kelamin")

# Dropdown dari database
def ambil_opsi(kolom):
    conn = connect_to_sql_server()
    df = pd.read_sql(f"SELECT DISTINCT {kolom} FROM Tabel_DataPenduduk", conn)
    conn.close()
    return ["Semua"] + sorted(df[kolom].dropna().tolist())

st.sidebar.selectbox("Pendidikan", ambil_opsi("Pendidikan"), key="pendidikan")
st.sidebar.selectbox("Pekerjaan", ambil_opsi("Pekerjaan"), key="pekerjaan")
st.sidebar.selectbox("Alamat", ambil_opsi("Alamat"), key="alamat")
st.sidebar.selectbox("Status_Keluarga", ambil_opsi("Status_Keluarga"), key="status_keluarga")
st.sidebar.selectbox("Status_Perkawinan", ambil_opsi("Status_Perkawinan"), key="status_perkawinan")

# NKK
nkk_input = st.sidebar.text_input("Nomor Kartu Keluarga (16 digit, opsional)", key="nkk_input")
if nkk_input and (not nkk_input.isdigit() or len(nkk_input) != 16):
    st.sidebar.error("NKK harus berupa 16 digit angka.")
    st.stop()

if st.sidebar.button("🔄 Reset Filter", on_click=reset_filters):
    st.rerun()

# ============ TAMPILKAN HASIL ============
filtered_data = get_filtered_data(
    st.session_state.umur_min,
    st.session_state.umur_max,
    st.session_state.jenis_kelamin,
    st.session_state.pendidikan,
    st.session_state.pekerjaan,
    st.session_state.alamat,
    st.session_state.status_keluarga,
    st.session_state.status_perkawinan,
    nkk_input
)

st.subheader("📄 Hasil Pencarian")
st.write(f"Menampilkan {len(filtered_data)} data:")
st.dataframe(filtered_data)

# ============ UNDUH ============
csv = filtered_data.to_csv(index=False).encode("utf-8")
st.download_button("⬇️ Unduh CSV", data=csv, file_name="hasil_pencarian.csv", mime="text/csv")

if st.button("🖨️ Unduh PDF"):
    pdf_path = generate_pdf(filtered_data)
    with open(pdf_path, "rb") as f:
        st.download_button("⬇️ Klik untuk unduh PDF", data=f, file_name="hasil_pencarian.pdf", mime="application/pdf")

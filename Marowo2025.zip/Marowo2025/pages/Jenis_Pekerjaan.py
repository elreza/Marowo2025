import altair as alt
import pandas as pd
import streamlit as st
import pyodbc



server = '10.0.0.36'
database = 'db_penduduk'
username = 'moh_sabri'
password = 'moh_sabri'

conn = pyodbc.connect (
    f'DRIVER={{ODBC Driver 17 for SQL Server}};'
    f'SERVER={server};'
    f'DATABASE={database};'
    f'UID={username};'
    f'PWD={password}'
)

# Query ambil data pekerjaan
query = "SELECT Pekerjaan FROM Tabel_DataPenduduk"
df = pd.read_sql(query, conn)

# Bersihkan data
df['Pekerjaan'] = df['Pekerjaan'].str.upper().str.strip()
df = df.dropna(subset=['Pekerjaan'])

# Hitung jumlah per pekerjaan
jumlah_pekerjaan = df['Pekerjaan'].value_counts().reset_index()
jumlah_pekerjaan.columns = ['Pekerjaan', 'Jumlah']

# Hitung persentase
total = jumlah_pekerjaan['Jumlah'].sum()
jumlah_pekerjaan['Persentase'] = (jumlah_pekerjaan['Jumlah'] / total * 100).round(2)

# Jumlah kategori yang ingin ditampilkan
top_n = 20
jumlah_terbatas = jumlah_pekerjaan.head(top_n)

# Chart dengan Altair
chart = alt.Chart(jumlah_terbatas).mark_bar().encode(
    x=alt.X('Pekerjaan:N', sort='-y', title='Jenis Pekerjaan'),
    y=alt.Y('Jumlah:Q', title='Jumlah Penduduk'),
    color=alt.Color('Pekerjaan:N', scale=alt.Scale(scheme='category20')),
    tooltip=[
        alt.Tooltip('Pekerjaan:N'),
        alt.Tooltip('Jumlah:Q'),
        alt.Tooltip('Persentase:Q', format='.2f')
    ]
).properties(
    width=700,
    height=400,
    title=f'Top {top_n} Jenis Pekerjaan Warga Desa Marowo'
)

# Tampilkan chart
st.altair_chart(chart, use_container_width=True)

# Tampilkan tabel di bawah chart
st.markdown("### Tabel Distribusi Pekerjaan (Top 12)")
st.dataframe(jumlah_terbatas, use_container_width=True)
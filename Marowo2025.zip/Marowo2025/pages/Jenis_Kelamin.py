import streamlit as st
import pandas as pd
import plotly.express as px
import pyodbc

# koneksi server
server = '10.0.0.36'
database = 'db_penduduk'
username = 'moh_sabri'
password = 'moh_sabri'

conn = pyodbc.connect (
    f'DRIVER={{ODBC Driver 17 for SQL Server}};'
    f'SERVER={server};'
    f'DATABASE={database};'
    f'UID={username};'
    f'PWD={password}'
)

# Ambil data
query = "SELECT Jenis_Kelamin FROM Tabel_DataPenduduk"
df = pd.read_sql(query, conn)

# Bersihkan data
df['Jenis_Kelamin'] = df['Jenis_Kelamin'].str.upper().str.strip()
df = df.dropna(subset=['Jenis_Kelamin'])

# Hitung jumlah
gender_counts = df['Jenis_Kelamin'].value_counts().reset_index()
gender_counts.columns = ['Jenis_Kelamin', 'Jumlah']

# Hitung persentase
gender_counts['Persentase'] = (gender_counts['Jumlah'] / gender_counts['Jumlah'].sum() * 100).round(2)

# Pie chart dengan plotly express
fig = px.pie(gender_counts,
             names='Jenis_Kelamin',
             values='Jumlah',
             color='Jenis_Kelamin',
             color_discrete_map={'LAKI - LAKI': 'blue', 'PEREMPUAN': 'red'},
             hole=0.3)

fig.update_traces(textinfo='percent+label', textfont_size=16)
fig.update_layout(title_text='Distribusi Jenis Kelamin')

st.plotly_chart(fig, use_container_width=True)

# Tabel deskripsi di bawah chart
st.markdown("### Rincian Persentase")
st.dataframe(gender_counts, use_container_width=True)
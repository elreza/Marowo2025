import altair as alt
import pandas as pd
import streamlit as st
import pyodbc



server = '10.0.0.36'
database = 'db_penduduk'
username = 'moh_sabri'
password = 'moh_sabri'

conn = pyodbc.connect (
    f'DRIVER={{ODBC Driver 17 for SQL Server}};'
    f'SERVER={server};'
    f'DATABASE={database};'
    f'UID={username};'
    f'PWD={password}'
)

# Query ambil data pekerjaan
query = "SELECT Pendidikan FROM Tabel_DataPenduduk"
df = pd.read_sql(query, conn)

# Bersihkan data
df['Pendidikan'] = df['Pendidikan'].str.upper().str.strip()
df = df.dropna(subset=['Pendidikan'])

# Hitung jumlah per pekerjaan
jumlah_pendidikan = df['Pendidikan'].value_counts().reset_index()
jumlah_pendidikan.columns = ['Pendidikan', 'Jumlah']

# Hitung persentase
total = jumlah_pendidikan['Jumlah'].sum()
jumlah_pendidikan['Persentase'] = (jumlah_pendidikan['Jumlah'] / total * 100).round(2)

# Jumlah kategori yang ingin ditampilkan
top_n = 12
jumlah_terbatas = jumlah_pendidikan.head(top_n)

# Chart dengan Altair
chart = alt.Chart(jumlah_terbatas).mark_bar().encode(
    x=alt.X('Pendidikan:N', sort='-y', title='Jenis Pendidikan'),
    y=alt.Y('Jumlah:Q', title='Jumlah Penduduk'),
    color=alt.Color('Pendidikan:N', scale=alt.Scale(scheme='category20')),
    tooltip=[
        alt.Tooltip('Pendidikan:N'),
        alt.Tooltip('Jumlah:Q'),
        alt.Tooltip('Persentase:Q', format='.2f')
    ]
).properties(
    width=700,
    height=400,
    title=f'Top {top_n} Jenis Pekerjaan Warga Desa Marowo'
)

# Tampilkan chart
st.altair_chart(chart, use_container_width=True)

# Tampilkan tabel di bawah chart
st.markdown("### Tabel Distribusi Pekerjaan (Top 12)")
st.dataframe(jumlah_terbatas, use_container_width=True)